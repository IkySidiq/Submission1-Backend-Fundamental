const { AlbumsPayloadSchema } = require('./schema'); // asumsikan schema.js ada di folder yang sama
const InvariantError = require('../../exceptions/InvariantError');

const AlbumsValidator = {
  validateAlbumPayload: (payload) => {
    const validationResult = AlbumsPayloadSchema.validate(payload);
    if (validationResult.error) {
      throw new InvariantError(validationResult.error.message);
    }
  },

  validateImageHeaders: (headers) => {
    const contentType = headers['content-type'];
    if (!contentType || !contentType.startsWith('image/')) {
      throw new InvariantError('File harus berupa gambar');
    }
  },
};

module.exports = AlbumsValidator;
