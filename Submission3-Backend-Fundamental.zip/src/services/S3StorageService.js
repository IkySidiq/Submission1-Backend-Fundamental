const { S3Client, PutObjectCommand } = require('@aws-sdk/client-s3');
const { nanoid } = require('nanoid');
const path = require('path');

class S3StorageService {
  constructor() {
    this._s3 = new S3Client({
      region: process.env.AWS_REGION,
      credentials: {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID,
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
      },
    });

    this._bucketName = process.env.AWS_BUCKET_NAME;
  }

  async writeFile(file, meta) {
    const extension = path.extname(meta.filename);
    const filename = `cover-${nanoid(16)}${extension}`;

    const params = {
      Bucket: this._bucketName,
      Key: filename,
      Body: file,
      ContentType: meta.headers['content-type'],
    };

    await this._s3.send(new PutObjectCommand(params));

    // URL public object S3
    const coverUrl = `https://${this._bucketName}.s3.${process.env.AWS_REGION}.amazonaws.com/${filename}`;
    return coverUrl;
  }
}

module.exports = S3StorageService;
